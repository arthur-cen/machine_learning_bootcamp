# hw2 problem 1, 3 code
import numpy as np
import scipy
from scipy.stats import multivariate_normal
import matplotlib.pyplot as plt
def question1():
	"""a"""
	N = 100
	mean = (4, 3)
	cov = [[4, 0], [0, 9]]
	samples = np.random.multivariate_normal(mean, cov, N).T

	sample_mean = np.mean(samples, axis = 1)
	sample_std = np.std(samples, axis = 1)
	print("1-a")
	print("sample mean = ", sample_mean)
	print("sample std = ", sample_std)
	"""b"""
	cov_matx = np.cov(samples)
	print("1-b")
	print("The Covariance matrix of the sample data:")
	print(cov_matx)

	"""c"""
	eig_val, eig_vec = np.linalg.eig(cov_matx)
	print("1-c")
	print("eigenvalues are ")
	print(eig_val)
	print("eigenvectors are")
	print(eig_vec)

	"""d"""
	print("1-d, plots:")
	arrow = eig_vec * eig_val
	u, v = zip(*(arrow))
	u = u + sample_mean
	v = v + sample_mean

	X1 = samples[0, :]
	X2 = samples[1, :]
	plt.figure()
	ax = plt.gca()
	ax.set_xlim([-15, 15])
	ax.set_ylim([-15, 15])
	plt.draw()
	plt.plot(X1[:], X2[:],'ro')
	ax.arrow(mean[0], mean[1], eig_vec[0][0] * eig_val[0],  eig_vec[1][0] * eig_val[0]) 
	ax.arrow(mean[0], mean[1], eig_vec[0][1] * eig_val[1],  eig_vec[1][1] * eig_val[1])
	plt.savefig('1d.png') 
	plt.clf()

	"""e"""
	array = np.array([[mean[0] for i in range(0, N)], [mean[1] for i in range(0, N)]])
	x = samples - array  
	x_rotated = eig_vec.T.dot(x) 
	print("1-e, plots:")
	# plot 
	ax = plt.gca()
	ax.set_xlim([-15, 15])
	ax.set_ylim([-15, 15])
	plt.plot(x_rotated[0], x_rotated[1], 'ro') 
	plt.savefig('1e.png')
	plt.clf()

def question3():
	"""a"""
	mean_a = (1, 1)
	cov_a = [[1, 0], [0, 2]]
	rv_a = scipy.stats.multivariate_normal(mean_a, cov_a)
	X_a, Y_a = np.mgrid[-10:10:0.2, -10:10:0.2]
	plt.contour(X_a, Y_a, rv_a.pdf(np.dstack((X_a, Y_a))), 30)
	plt.savefig("3-a")
	plt.clf()
	"""b"""
	mean_b = (-1, 2)
	cov_b = [[2,1], [1,3]]
	rv_b = scipy.stats.multivariate_normal(mean_b, cov_b)
	X_b, Y_b = np.mgrid[-10:10:0.2, -10:10:0.2]
	plt.contour(X_b, Y_b, rv_b.pdf(np.dstack((X_b, Y_b))), 30)
	plt.savefig("3-b")
	plt.clf()

	"""c"""
	mean_c_1 = (0, 2)
	mean_c_2 = (2, 0)
	cov_c = [[2, 1], [1, 1]]
	rv_c_1 = scipy.stats.multivariate_normal(mean_c_1, cov_c)
	rv_c_2 = scipy.stats.multivariate_normal(mean_c_2, cov_c)
	X_c, Y_c = np.mgrid[-10:10:0.2, -10:10:0.2]
	plt.contour(X_c, Y_c, rv_c_1.pdf(np.dstack((X_c, Y_c))) - rv_c_2.pdf(np.dstack((X_c, Y_c))), 20)
	plt.savefig("3-c")
	plt.clf()


	"""d"""
	mean_d_1 = (0, 2)
	mean_d_2 = (2, 0)
	cov_d_1 = [[2, 1], [1, 1]]
	cov_d_2 = [[2, 1], [1, 3]]
	rv_d_1 = scipy.stats.multivariate_normal(mean_d_1, cov_d_1)
	rv_d_2 = scipy.stats.multivariate_normal(mean_d_2, cov_d_2)
	X_d, Y_d = np.mgrid[-10:10:0.2, -10:10:0.2]
	plt.contour(X_d, Y_d, rv_d_1.pdf(np.dstack((X_d, Y_d))) - rv_d_2.pdf(np.dstack((X_d, Y_d))), 20)
	plt.savefig("3-d")
	plt.clf()

	"""e"""
	mean_e_1 = (1 , 1)
	mean_e_2 = (-1, -1)
	cov_e_1 = [[2, 0], [0, 1]]
	cov_e_2 = [[2, 1], [1, 2]]
	rv_e_1 = scipy.stats.multivariate_normal(mean_e_1, cov_e_1)
	rv_e_2 = scipy.stats.multivariate_normal(mean_e_2, cov_e_2)
	X_e, Y_e = np.mgrid[-10:10:0.2, -10:10:0.2]
	plt.contour(X_e, Y_e, rv_e_1.pdf(np.dstack((X_e, Y_e))) - rv_e_2.pdf(np.dstack((X_e, Y_e))), 20)
	plt.savefig("3-e")
	plt.clf()


if __name__ == "__main__":
	question1()
	question3()
